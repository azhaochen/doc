var axios = require('axios');
var Pool  = require('../socketpool/index.js');

//（动态获取ip地址，可选，目前上报tdbank的接口可以直接通过bid找到相应的集群）
var bus_cgf_url="http://tl-tdbank-tdmanger.tencent-distribute.com:8099/api/tdbus_ip?cluster_id=2&net_tag=all";
var bus_cfg_cache = {};
var bus_cfg_lasttime = 0;           //已过期。初始状态
var bus_cfg_cachetime = 5*1000;//5*60*1000;  //5分钟缓存
var pool = null;
var report_queue = [];              //上报队列

// function get_data(){
//     return new Promise(function(resolve, reject){
//         axios.get(bus_cgf_url).then(
//             data => {
//                 resolve(data);
//             },
//             err => {
//                 resolve(err);   //这里转为resolve，否则，用reject会导致await后面报错
//             }
//         ).catch(err=>{
//             resolve(err);       //这里转为resolve
//         })
//     })
// }
// function get_data(){
//     return axios.get(bus_cgf_url);
// }


//获取8、14、17位日期戳格式
function getTimeStamp(len){
    var zeroize = function (value, length) {
        if (!length) length = 2;
        value = String(value);
        for(var i=0, zeros=''; i<(length-value.length); i++) {
            zeros += '0';
        }
        return zeros + value;
    };

    var d = new Date();
    var str = ''+d.getFullYear() + zeroize(d.getMonth()+1) + zeroize(d.getDate());  //20190408
    if(len==14){
        str += d.getHours() + zeroize(d.getMinutes()) + zeroize(d.getSeconds());
    }else if(len==17){
        str += d.getHours() + zeroize(d.getMinutes()) + zeroize(d.getSeconds()) + zeroize(d.getMilliseconds(), 3)
    }
    return str;
}


/*  
    组装mo消息格式，用于socket.write
    params: sysID, intfID, other indexes
*/
module.exports.composeMoFormat = function(params){
    let timestamp = getTimeStamp(17);
    let attr = "bid=b_teg_rt_index&tid=tip&dt=" + Date.now();   //bid写死b_teg_rt_index，tid用不到随意。dt精确到毫秒的unix时间戳整型
    let body = `sysID=${params.sysID}&intfID=${params.intfID}&set=SZ&buID=IEG&retType=0&timestamp=${timestamp}&logtime=${timestamp}`;
    for(var a in params){
        body += '&'+a+'='+params[a];    //'total=1&failed=0&logictime=100&result=-1&ip_port=1.1.1.1&api_url=api&channel=ad&module=tipcomm'
    }
    //二进制： 4字节(总长，不含自身) + 1字节(消息类型) + 4字节(body len) + body + 4字节(attr len) + attr
    let totallen = 1+4+body.length+4+attr.length;       //总长不包括自身。由于都是字母数字，故可以直接用length
    let buff = Buffer.alloc(totallen+4);
    let next=0, succ=0;                                 //下一个位置，成功写入量
    next = buff.writeInt32BE(totallen, next);           //写入4字节。网络是大头序
    next = buff.writeInt8(2,next);                      //写入1字节。消息类型为2【无回包】。参考：http://km.oa.com/group/20523/articles/show/176350
    next = buff.writeInt32BE(body.length, next);        //写入4字节
    succ = buff.write(body, next, body.length);         //写入body string
    next+= succ;
    next = buff.writeInt32BE(attr.length, next);        //写入4字节
    succ = buff.write(attr, next, attr.length);         //写入attr string

    return buff;
}



/*
    读取tdw平台ip节点配置
*/
async function getMoCfg(){
    if(Date.now() - bus_cfg_lasttime > bus_cfg_cachetime || !bus_cfg_cache.host){
        //let data = await get_data().catch(err=>{console.err(err);});
        let data = await axios.get(bus_cgf_url).catch(err=>{console.err('query mo cfg error, '+(err.msg||''));});
        if(data.data && data.data.port && data.data.host){
            bus_cfg_cache = {
                port: data.data.port,
                host: Object.values(data.data.host)
            };
            bus_cfg_lasttime = Date.now();
        }else if(!bus_cfg_cache.host){
            return false;
        }
    }
    return bus_cfg_cache;
}

/*
    刷新缓存、pool
*/
async function renewCache(){
    renewCache.doing_flag = ~~renewCache.doing_flag;    //initialize 0
    if(renewCache.doing_flag==0){
        renewCache.doing_flag = 1;
    }else{
        return true;
    }
    console.info('..renewCache start...')

    //没有配置，或者没有pool，或者配置过期
    if(Date.now()-bus_cfg_lasttime>bus_cfg_cachetime || !bus_cfg_cache.host || !pool){
        let tmp = await getMoCfg();
        renewCache.doing_flag = 0;
        let cfg = bus_cfg_cache;
        if(!cfg.host){
            if(!pool){
                console.error('mo cfg failed');                 //TODO：报错，告警
                return false;
            }
        }else{
            pool && pool.destory();                         //sync
            pool = null;
            let i = Math.floor(Math.random() * cfg.host.length);
            pool = new Pool([
                    { host: cfg.host[(i+0)%cfg.host.length], port: cfg.port, weight: 1},
                    { host: cfg.host[(i+1)%cfg.host.length], port: cfg.port, weight: 1},
                    { host: cfg.host[(i+2)%cfg.host.length], port: cfg.port, weight: 1},
                ], {min: 2,max: 3, debug:0}
            );
            console.log('renew pool finish');
        }
    }

    renewCache.doing_flag = 0;

    consumeQueue();
    return true;
}


/*
    处理队列
*/
function consumeQueue(){
    if(!pool){
        return;
    }
    while(report_queue.length){
        let senddata = report_queue.pop();
        let socket = pool.getClient();
        //任务函数，带params的偏函数
        let taskFun = (function(data){
            return function(socket){
                socket.on('data', function(data) {
                    console.info('.....receive data.....');
                });
                socket.on('close', function(){
                    console.info('.....socket closed....');
                })
                socket.write(data);
                console.info('.....send finish....');
                pool.release(socket);           //由于无回包，调用write后就立即释放socket
                //pool = socket = null;           //remove reference
            }
        })(senddata);
        senddata = null;

        if (socket) {
            taskFun(socket);
        } else {
            pool.adToQueue(taskFun);
        }

    }
}



/*
    用户上报Mo，入队列
*/
module.exports.reportMoAsync = function(params){
    if(!pool || Date.now()-bus_cfg_lasttime>bus_cfg_cachetime){
        renewCache();
    }

    var buff = this.composeMoFormat(params);
    report_queue.push(buff);
    //极特殊异常情况超长了，抛弃一半，重开pool，TODO：加告警
    let len = report_queue.length;
    if(len > 100000){
        console.error('exceed max report queue length.');
        report_queue = report_queue.filter(function(v, k){return k%2}); //0.5降采样
        pool = null;
        renewCache();
    }
    consumeQueue();
}



renewCache();       //启动时，执行一次初始化
