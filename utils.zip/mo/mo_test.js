var Socket = require('net').Socket;


//获取8、14、17位日期戳格式
function getTimeStamp(len){
    var zeroize = function (value, length) {
        if (!length) length = 2;
        value = String(value);
        for(var i=0, zeros=''; i<(length-value.length); i++) {
            zeros += '0';
        }
        return zeros + value;
    };

    var d = new Date();
    var str = ''+d.getFullYear() + zeroize(d.getMonth()+1) + zeroize(d.getDate());  //20190408
    if(len==14){
        str += d.getHours() + zeroize(d.getMinutes()) + zeroize(d.getSeconds());
    }else if(len==17){
        str += d.getHours() + zeroize(d.getMinutes()) + zeroize(d.getSeconds()) + zeroize(d.getMilliseconds(), 3)
    }
    return str;
}



function composeMoFormat(params){
    let timestamp = getTimeStamp(17);
    let attr = "bid=b_teg_rt_index&tid=tip&dt=" + Date.now();   //bid写死b_teg_rt_index，tid用不到随意。dt精确到毫秒的unix时间戳整型
    let body = `sysID=${params.sysID}&intfID=${params.intfID}&set=SZ&buID=IEG&retType=0&timestamp=${timestamp}&logtime=${timestamp}`;
    for(var a in params){
        body += '&'+a+'='+params[a];    //'total=1&failed=0&logictime=100&result=-1&ip_port=1.1.1.1&api_url=api&channel=ad&module=tipcomm'
    }
    //二进制： 4字节(总长) + 1字节(消息类型) + 4字节(body len) + body + 4字节(attr len) + attr
    let totallen = 1+4+body.length+4+attr.length;       //总长不包括自身。由于都是字母数字，故可以直接用length
    let buff = Buffer.alloc(totallen+4);
    let next=0, succ=0;                                 //下一个位置，成功写入量
    next = buff.writeInt32BE(totallen, next);           //写入4字节。网络是大头序
    next = buff.writeInt8(2,next);                      //写入1字节。消息类型为2。参考：http://km.oa.com/group/20523/articles/show/176350
    next = buff.writeInt32BE(body.length, next);        //写入4字节
    succ = buff.write(body, next, body.length);         //写入body string
    next+= succ;
    next = buff.writeInt32BE(attr.length, next);        //写入4字节
    succ = buff.write(attr, next, attr.length);         //写入attr string

    return buff;
}



//测试单连接。 （复用关闭连接的问题）
function testClient(i){
    var sock = new Socket();
    sock.once('error', function(err) {
        console.log('socket error...')
    });
    sock.once('timeout', function() {
        console.log('socket timeout...')
    });
    sock.once('close', function() {
        console.log('socket close...')
    });
    sock.connect(46801, '10.121.98.10');
    sock.once('connect', function() {
        console.log('socket connected...');
        let params = {
            sysID: '9900685',
            intfID: 1,
            total: 1,
            failed: i%2,
            logictime: 100,
            result: 500,
            ip_port: '1.1.1.1',
            api_url: 'api',
            channel: 'ad',
            module: 'tipcomm'
        };
        var buff = composeMoFormat(params)
        console.log(buff.toString())
        let a = sock.write(buff);
    });
    sock.on('data',function(data){
        console.log('socket receive data...',data);     //服务器回复后立刻关闭连接了，，'data'消息后会立马触发'close'事件。
    })
}


//测试，使用连接池pool
function testPool(){
    var Mo = require('./mo.js');
    for(var i=0; i<5; i++){
        let params = {
            sysID: '9900685',
            intfID: 1,
            total: 1,
            failed: i%2,
            logictime: 100*Math.floor(Math.random()*10),
            result: 500,
            ip_port: '1.1.1.1',
            api_url: 'api',
            channel: 'ad',
            module: 'tipcomm'
        };
        Mo.reportMoAsync(params);
    }

    setTimeout(function(){
        for(var i=5; i<10; i++){
            let params = {
                sysID: '9900685',
                intfID: 1,
                total: 1,
                failed: i%2,
                logictime: 100*Math.floor(Math.random()*10),
                result: 500,
                ip_port: '1.1.1.1',
                api_url: 'api',
                channel: 'ad',
                module: 'tipcomm'
            };
            Mo.reportMoAsync(params);
        }
    }, 6*1000)

}











testPool();

// for(var i=0; i< 5; i++){
//     testClient(i);
// }
